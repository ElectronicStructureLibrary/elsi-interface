Troubleshooting   {#pageTrouble}
===============

If you run into problems or would like to request additional features,
please email linlin@math.berkeley.edu. 

If you are having problems building the package, please
make sure to attach the `make.inc` file. An example of this file can be
found in the `config` directory.
