Download       {#pageDownload}
========


**Current version (v0.8.0)**:

- Code: <a href="https://math.berkeley.edu/~linlin/pexsi/download/download.php?file=pexsi_v0.8.0.tar.gz">pexsi_v0.8.0.tar.gz</a>


**Older version of %PEXSI**:

**v0.7.3**:
- Code: <a href="https://math.berkeley.edu/~linlin/pexsi/download/download.php?file=pexsi_v0.7.3.tar.gz">pexsi_v0.7.3.tar.gz</a>
- Documentation: <a href="https://math.berkeley.edu/~linlin/pexsi/download/doc_v0.7.3">[html]</a>

**v0.7.2**:

- Code: <a href="https://math.berkeley.edu/~linlin/pexsi/download/download.php?file=pexsi_v0.7.2.tar.gz">[pexsi_v0.7.2.tar.gz]</a>

**v0.7.1**:

- Code: <a href="https://math.berkeley.edu/~linlin/pexsi/download/download.php?file=pexsi_v0.7.1.tar.gz">[pexsi_v0.7.1.tar.gz]</a>
<!--
- Documentation: <a href="https://math.berkeley.edu/~linlin/pexsi/download/doc_v0.7.1">[html]</a>
-->


**v0.6.0**:

- Code: <a href="https://math.berkeley.edu/~linlin/pexsi/download/download.php?file=pexsi_v0.6.0.tar.gz">[pexsi_v0.6.0.tar.gz]</a>
- Documentation: <a href="https://math.berkeley.edu/~linlin/pexsi/download/doc_v0.6.0">[html]</a>

